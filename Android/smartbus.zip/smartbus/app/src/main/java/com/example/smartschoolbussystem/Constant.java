package com.example.smartschoolbussystem;

public class Constant {
    public static  final String  SERVER_URL="http://192.168.1.125:8080/api/";
}
