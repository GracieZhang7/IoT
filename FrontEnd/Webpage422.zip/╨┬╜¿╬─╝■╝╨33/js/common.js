$(function(){

	$("#On").click(function(){
		var userIdentification = $("#userIdentification").val();
		var userName = $("#userName").val();
		var busPlate = $("#busPlate").val();
		var datas={
			"userIdentification" : "51142245",
		    "userName" : "David",
		    "busPlate" : "ABCDE-12",
		    "locationId" : 1,
		    "eventType" : 1
		}
		
		$.ajax({
            url:'http://localhost:8080/api/events/save',
            contentType: "application/json",
            type: "post",
    		dataType: "json",
            data:JSON.stringify(datas),
            success:function(data){
            	console.log(data);
            },
            error:function(data){
               
            }

        })
	});
	$("#off").click(function(){
		var userIdentification = $("#userIdentification").val();
		var userName = $("#userName").val();
		var busPlate = $("#busPlate").val();
		var datas={
			"userIdentification" : "51142245",
		    "userName" : "David",
		    "busPlate" : "ABCDE-12",
		    "locationId" : 1,
		    "eventType" : 0
		}
		
		$.ajax({
            url:'http://localhost:8080/api/events/history',
            contentType: "application/json",
            type: "post",
    		dataType: "json",
            data:JSON.stringify(datas),
            success:function(data){
            	console.log(data);
            },
            error:function(data){
               
            }

        })
	});
});